<div>
    
    aqui crearemos un animal
    <div class="input-field col s12">
    <select wire:model="animalSelected">
        <?php $__currentLoopData = $animales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($animal->id); ?>"><?php echo e($animal->tipo); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label>Materialize Select</label>
  </div>
  <button data-target="modal1" class="btn modal-trigger">Modal</button>
          

  <!-- Modal Structure -->
  <div id="modal1" class="modal">
    <div class="modal-content">
      <h4>Nueva raza para <?php echo e($animalSelected); ?></h4>
      <p>A bunch of text</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Agree</a>
    </div>
  </div>

</div>
<?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/livewire/crear-animal.blade.php ENDPATH**/ ?>