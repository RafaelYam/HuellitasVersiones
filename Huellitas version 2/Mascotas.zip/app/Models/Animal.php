<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Animal extends Model
{
    use HasFactory;
    public function raza(){
        return $this->hasMany(Raza::class);
    }

    protected $fillable = ['id','tipo'];
    

}
