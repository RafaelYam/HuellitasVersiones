
<form>
    <div class="form-group">
        <label for="exampleFormControlInput1">Tipo de cuidado:</label>
        <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Escribir..." wire:model="tipocuidado">
        <?php $__errorArgs = ['tipocuidado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput2">Descripción:</label>
        <input type="text" class="form-control" id="exampleFormControlInput2" placeholder="Escribir..." wire:model="descripcion">
        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput3">Nombre del veterinario que le brindó la información:</label>
        <input type="text" class="form-control" id="exampleFormControlInput3" placeholder="Escribir..." wire:model="veterinario">
        <?php $__errorArgs = ['veterinario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput4">Contacto del veterinario:</label>
        <input type="text" class="form-control" id="exampleFormControlInput4"  wire:model="contactoveterinario">
        <?php $__errorArgs = ['contactoveterinario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button wire:click.prevent="store()" class="btn btn-success">Save</button>
</form>
<?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/livewire/cuidadoesp/create.blade.php ENDPATH**/ ?>