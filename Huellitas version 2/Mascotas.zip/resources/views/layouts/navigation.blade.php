<nav class="">
  <div class="nav-wrapper ">
    <a href="{{route('welcome')}}" class="brand-logo">Inicio</a>

    @if (Route::has('login'))
    <div align='right' class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
      @auth
      <ul class="right hide-on-med-and-down">


        <li><a class="dropdown-trigger" href="{{route('perfil')}}" data-target="dropdown1">{{ Auth::user()->name }} </a></li>
        <li class="col s12 m2"><a href="#">
            <form method="POST" action="{{ route('logout') }}">
              @csrf

              <x-dropdown-link :href="route('logout')" onclick="event.preventDefault();
                                                  this.closest('form').submit();">
                {{ __('Cerrar Sesion') }}
              </x-dropdown-link>
            </form>
          </a></li>
      </ul>
      @else
      <a href="{{ route('login') }}" class="login">Iniciar Sesión</a>

      @if (Route::has('register'))
      <a href="{{ route('register') }}" class="register">Registrar</a>
      @endif
      @endauth
    </div>
    @endif
  </div>
</nav>