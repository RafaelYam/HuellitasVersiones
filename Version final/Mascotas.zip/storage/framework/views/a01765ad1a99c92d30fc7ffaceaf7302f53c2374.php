<div>
    
    <div class="row">
    <?php $__currentLoopData = $dato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    
        <div class="card sticky-action col s12 m4 s4">
            <div class="card-image waves-effect waves-block waves-light">
                <img class="activator" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Laravel.svg/1200px-Laravel.svg.png" width="50" height="150">
            </div>
            <div class="card-content">
                <span class="card-title activator grey-text text-darken-4"><?php echo e($vacuna->nombre); ?><i class="material-icons right">more_vert</i></span>
                <p><a href="#">This is a link</a></p>
            </div>
            <div class="card-reveal">
                <span class="card-title grey-text text-darken-4">Card Title<i class="material-icons right">close</i></span>
                <p>Here is some more information about this product that is only revealed once clicked on.</p>
            </div>
        </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
</div><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/livewire/vacunaanimal.blade.php ENDPATH**/ ?>