
<?php $__env->startSection('informacion'); ?>

<div class=" fondo container">
   <div>
    <h1>La probabilidad de enfermarse del <?php echo e($mascota->raza); ?> es de:</h1>
    <p><?php echo e($mascota->sintomas); ?></p>
   </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/info/enfermarse.blade.php ENDPATH**/ ?>