<div>
    

    <section id="service" class="relative services-area py-120 container">
        <div class="title">Seleccione el sintoma que presenta su mascota para determinar su enfermedad</div>
        <br>
        <div class="grid grid-cols-6 gap-4">
            <div class="col-start-1 col-end-3">
                <?php $__currentLoopData = $sintomas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sintoma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="py-3"><button class="relative px-6 py-3 group " wire:click="activar(<?php echo e($sintoma->id); ?>)">
                        <span class="absolute inset-0 w-full h-full transition duration-300 ease-out transform translate-x-1 translate-y-1 bg-cyan-700 group-hover:-translate-x-0 group-hover:-translate-y-0"></span>
                        <span class="absolute inset-0 w-full h-full bg-white border-2 border-cyan-700 group-hover:bg-cyan-700"></span>
                        <span class="relative text-cyan-700 group-hover:text-cyan-100"> <?php echo e($sintoma->descripcion); ?></span>
                    </button></ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                    <ul class="py-3"><button class="relative px-6 py-3 group " wire:click="activarmapa">
                        <span class="absolute inset-0 w-full h-full transition duration-300 ease-out transform translate-x-1 translate-y-1 bg-red-700 group-hover:-translate-x-0 group-hover:-translate-y-0"></span>
                        <span class="absolute inset-0 w-full h-full bg-white border-2 border-red-700 group-hover:bg-red-500"></span>
                        <span class="relative text-red-700 group-hover:text-white"> Si no encuentras los sintomas de <br> tu macota, presione aqui para ver a los <br> veterinarrios cercanos</span>
                    </button></ul>


            </div>
            <div class="col-start-4 col-end-7">

                <?php if($mostrar): ?>
                <h1>Información</h1>
                <?php $__currentLoopData = $informacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="flex justify-center">
                    <div class="block rounded-lg shadow-lg bg-white max-80 text-justify">
                        <div class="py-3 px-6 border-b border-gray-300">
                            <h5 class="text-gray-900 text-xl font-medium mb-2"><?php echo e($informa->nombre); ?></h5>
                        </div>
                        <div class="p-6">

                            <p class="text-gray-700 text-base mb-4">
                                <?php echo e($informa->descripcion); ?>

                            </p>

                        </div>
                        <div class="py-3 px-6 border-t border-gray-300 text-gray-600">
                            <?php echo e($informa->probabilidad); ?>% probabilidad de sobrevivir
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>



                <?php if($mostrarmapa): ?>
                <h1>Mapa de veterinarios cercanos</h1>
                

                <div class="flex justify-center">
                    <div class="block rounded-lg shadow-lg bg-white max-80 text-justify">
                        <div class="py-3 px-6 border-b border-gray-300">
                            <h5 class="text-gray-900 text-xl font-medium mb-2">Motul, Yucatán</h5>
                        </div>
                        <div class="p-6">

                            <p class="text-gray-700 text-base mb-4">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d7444.753285262948!2d-89.2873064!3d21.0975451!3m2!1i1024!2i768!4f13.1!2m1!1sveterinarios%20motul%20yucatan!5e0!3m2!1ses-419!2smx!4v1654613799016!5m2!1ses-419!2smx" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </p>

                        </div>
                        <div class="py-3 px-6 border-t border-gray-300 text-gray-600">
                            
                        </div>
                    </div>
                </div>
                

                <?php endif; ?>
            </div>
        </div>

        <div>
            
        </div>
    </section>
</div><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/livewire/sintomas.blade.php ENDPATH**/ ?>