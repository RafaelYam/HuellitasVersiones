<div>
    {{-- Stop trying to control. --}}
    <p>{{$criterio}}</p>
<div>
    <input type="text" wire:model="criterio">
</div>
{{$criterio}}
<div class="relative overflow-x-auto shadow-md sm:rounded-lg">
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="px-6 py-3">
                    Raza
                </th>
                <th scope="col" class="px-6 py-3">
                    Información
                </th>
                <th scope="col" class="px-6 py-3">
                    Picture
                </th>
            </tr>
        </thead>
        <tbody>
            @foreach($razas as $user)
            <tr class="border-b dark:bg-gray-800 dark:border-gray-700 odd:bg-white even:bg-gray-50 odd:dark:bg-gray-800 even:dark:bg-gray-700">
                <th scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                    {{$user->raza}}
                </th>
                <td class="px-6 py-4">
                    {{$user->informa}}
                </td>

                <td class="px-6 py-4 text-right">

                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
</div>

