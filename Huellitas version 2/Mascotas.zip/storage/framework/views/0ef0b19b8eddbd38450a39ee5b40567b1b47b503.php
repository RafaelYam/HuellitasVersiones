
<?php $__env->startSection('informacion'); ?>

<div class="fondo">
    <div>
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
        <!-- Modal Trigger -->
        <a class="waves-effect waves-light btn modal-trigger" href="#modal1">Administrar especies</a>

        <!-- Modal Structure -->
        <div id="modal1" class="modal">
            <div class="modal-content">
                <h4>Actividades de administrador</h4>
            </div>
            <div class="container mt-5">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-body">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('especies', [])->html();
} elseif ($_instance->childHasBeenRendered('lDLGeAd')) {
    $componentId = $_instance->getRenderedChildComponentId('lDLGeAd');
    $componentTag = $_instance->getRenderedChildComponentTagName('lDLGeAd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lDLGeAd');
} else {
    $response = \Livewire\Livewire::mount('especies', []);
    $html = $response->html();
    $_instance->logRenderedChild('lDLGeAd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="#!" class="modal-close waves-effect waves-green btn-flat">Agree</a>
            </div>
        </div>
        
    </div>
    
    <?php endif; ?>
</div>
<div class="row">


    <?php $__currentLoopData = $mascota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col s12 m6 l3">
        <div class="card deep-purple lighten-3">
            <div class="card-content white-text">
                <span class="card-title"><?php echo e($animal->nombre); ?></span>
                <p><?php echo e($animal->raza->raza); ?></p>
            </div>
            <div class="card-action">
                <p>Au: <?php echo e($animal->user->name); ?></p>
                <div>
                    <a href="<?php echo e(route('mascota.verinfo', $animal->raza_id)); ?>" class="btn-floating btn-small waves-effect  indigo lighten-1 tooltipped" data-position="bottom" data-tooltip="Información"><i class="material-icons">pets</i></a>
                    <a href="<?php echo e(route('mascota.show', $animal->id)); ?>" class="btn-floating btn-small waves-effect  indigo lighten-1 tooltipped" data-position="bottom" data-tooltip="Ver"><i class="material-icons">pets</i></a>
                    <a href="" class="btn-floating btn-small waves-effect  indigo lighten-1 tooltipped" data-position="bottom" data-tooltip="Enfermedades"><i class="material-icons">local_hospital</i></a>
                    <a href="" class="btn-floating btn-small waves-effect  indigo lighten-1 tooltipped" data-position="bottom" data-tooltip="Alimentación"><i class="material-icons">local_dining</i></a>

                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="col s12 m6 l3">
        <div class="card deep-purple lighten-3">
            <div class="card-content white-text">
                <span class="card-title">¿Es momento de una nueva mascota?</span>
                <p>no es demasiado tarde para hacer crecer tu familia</p>
            </div>
            <div class="card-action">
                <a href="<?php echo e(route('mascota.create')); ?>" class="waves-effect waves-light  indigo lighten-1 btn-small">Añadir nueva mascota</a>
            </div>
        </div>
    </div>

</div>
</div>


<script>
    $(document).ready(function() {
        $('.tooltipped').tooltip();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/perfil.blade.php ENDPATH**/ ?>