<?php return array (
  'alimentos' => 'App\\Http\\Livewire\\Alimentos',
  'crear-animal' => 'App\\Http\\Livewire\\CrearAnimal',
  'cuidadoespuser' => 'App\\Http\\Livewire\\Cuidadoespuser',
  'cuidadogeneral' => 'App\\Http\\Livewire\\Cuidadogeneral',
  'especies' => 'App\\Http\\Livewire\\Especies',
  'show-razas' => 'App\\Http\\Livewire\\ShowRazas',
);