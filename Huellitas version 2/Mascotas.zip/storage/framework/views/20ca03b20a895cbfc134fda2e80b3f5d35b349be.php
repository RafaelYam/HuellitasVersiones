
<?php $__env->startSection('informacion'); ?>

<ul class="collapsible">
    <?php echo e($animalc->count()); ?>

    <?php $__currentLoopData = $animalc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
      <div class="collapsible-header"><i class="material-icons">filter_drama</i><?php echo e($animal->tipo); ?></div>
      <?php $__currentLoopData = $animal->raza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="collapsible-body"><a href="<?php echo e(route('mascota.verinfo', $raza->id)); ?>"><span><?php echo e($raza->raza); ?></span></a></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>

<script>
      $(document).ready(function(){
    $('.collapsible').collapsible();
  });
       
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/lista/animal.blade.php ENDPATH**/ ?>