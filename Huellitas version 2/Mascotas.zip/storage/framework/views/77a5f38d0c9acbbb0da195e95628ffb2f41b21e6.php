
<?php $__env->startSection('informacion'); ?>

<div class="row">
    <div class="col s7">
        <p>Aqui van cuidados</p>
    </div>
    <div class="col s5">
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cuidadoespuser', [])->html();
} elseif ($_instance->childHasBeenRendered('pWwskOt')) {
    $componentId = $_instance->getRenderedChildComponentId('pWwskOt');
    $componentTag = $_instance->getRenderedChildComponentTagName('pWwskOt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pWwskOt');
} else {
    $response = \Livewire\Livewire::mount('cuidadoespuser', []);
    $html = $response->html();
    $_instance->logRenderedChild('pWwskOt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/lista/cuidado.blade.php ENDPATH**/ ?>