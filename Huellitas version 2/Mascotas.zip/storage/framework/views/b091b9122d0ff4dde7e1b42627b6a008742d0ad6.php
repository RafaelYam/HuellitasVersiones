<div>
    
    <p><?php echo e($criterio); ?></p>
<div>
    <input type="text" wire:model="criterio">
</div>
<?php echo e($criterio); ?>

<div class="relative overflow-x-auto shadow-md sm:rounded-lg">
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="px-6 py-3">
                    Raza
                </th>
                <th scope="col" class="px-6 py-3">
                    Información
                </th>
                <th scope="col" class="px-6 py-3">
                    Picture
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $razas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b dark:bg-gray-800 dark:border-gray-700 odd:bg-white even:bg-gray-50 odd:dark:bg-gray-800 even:dark:bg-gray-700">
                <th scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-white whitespace-nowrap">
                    <?php echo e($user->raza); ?>

                </th>
                <td class="px-6 py-4">
                    <?php echo e($user->informa); ?>

                </td>

                <td class="px-6 py-4 text-right">

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>

<?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/livewire/show-razas.blade.php ENDPATH**/ ?>