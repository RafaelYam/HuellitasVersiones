
<?php $__env->startSection('informacion'); ?>

<div class=" fondo container">
   <div>
    <h1>Los sintomas más comunes en esta raza son:</h1>
    <p><?php echo e($mascota->sintomas); ?></p>
   </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/info/sintomas.blade.php ENDPATH**/ ?>