<div>
    
    <div>
        
        <?php if($isOpen): ?>
            <?php echo $__env->make('livewire.cuidadogen.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('livewire.cuidadogen.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <table class="table table-bordered mt-5">
            <thead>
                <tr>
                    <th>Tipo de cuidado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cuidados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($value->tipocuidado); ?></td>
                    <td>
                        <button wire:click="edit(<?php echo e($value->id); ?>)" class="btn btn-primary btn-sm">Edit</button>
                        <button wire:click="delete(<?php echo e($value->id); ?>)" class="btn btn-danger btn-sm">Delete</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/livewire/cuidadogeneral.blade.php ENDPATH**/ ?>