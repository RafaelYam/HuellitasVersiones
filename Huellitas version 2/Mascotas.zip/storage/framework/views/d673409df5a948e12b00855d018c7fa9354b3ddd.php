<!-- Dropdown Structure -->

<nav class="green accent-3">
  <div class="nav-wrapper">
    <a href="<?php echo e(url('/')); ?>" class="brand-logo">Inicio</a>
    <?php if(Route::has('login')): ?>
                <div align='right' class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
      
    <ul class="right hide-on-med-and-down">
      
    
  </div>
  
</nav>

<?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/layouts/nonavigation.blade.php ENDPATH**/ ?>