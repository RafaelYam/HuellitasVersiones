@extends('layouts.miapp')
@section('informacion')
<section class="img-estatica">
    <div class="TituloPagina">
        <div class="nombre-pagina">
            <h1 class="nombre">Huellitas:</h1>
            <h4 class="segundo-nombre">Veterinario en casa</h5>
        </div>
        <a href="">
            <div class="botones">
                <p class="letra-boton">Más Información</p>
            </div>
        </a>
    </div>

    <div class="Boton" align="right">
        <a href="{{route('mascota.create')}}" class="waves-effect waves-light small btn">Muestranos a tu mascota</a>
    </div>

    <div class="row CardsIndex container">
        
        <div class="informacion-index">
            <h1 class="letra-cuadro-index">Información</h1>
            <a href="{{route('mascota.lista')}}">
                <img class="foto-index" src="https://cdn-icons-png.flaticon.com/512/3047/3047886.png" alt="" width="200" height="200">
                <p class="letra-cuadro-index-p-a">Saber más</p>
            </a>
        </div>
        
        <div class="cuidado-index">
            <h1 class="letra-cuadro-index">Enfermedades</h1>
            <a href="">
                <img src="https://cdn-icons-png.flaticon.com/512/5276/5276963.png" alt="" width="200" height="200">
                <p class="letra-cuadro-index-p">Saber más</p>
            </a>

        </div>
        
        <div class="alimento-index">
            <h1 class="letra-cuadro-index">Alimentación</h1>
            <a href="">
                <img class="foto-index" src="https://cdn-icons-png.flaticon.com/512/3047/3047886.png" alt="" width="200" height="200">
                <p class="letra-cuadro-index-p-a">Saber más</p>
            </a>
        </div>
    </div>

</section>
<div class="margen">


</div>

@endsection