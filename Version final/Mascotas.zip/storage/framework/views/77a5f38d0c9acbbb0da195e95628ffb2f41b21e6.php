
<?php $__env->startSection('informacion'); ?>

<div class="row">
    <div class="col s7">
        <p>Aqui van cuidados</p>
    </div>
    <div class="col s5">
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cuidadoespuser', [])->html();
} elseif ($_instance->childHasBeenRendered('jUI9BA1')) {
    $componentId = $_instance->getRenderedChildComponentId('jUI9BA1');
    $componentTag = $_instance->getRenderedChildComponentTagName('jUI9BA1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jUI9BA1');
} else {
    $response = \Livewire\Livewire::mount('cuidadoespuser', []);
    $html = $response->html();
    $_instance->logRenderedChild('jUI9BA1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/lista/cuidado.blade.php ENDPATH**/ ?>