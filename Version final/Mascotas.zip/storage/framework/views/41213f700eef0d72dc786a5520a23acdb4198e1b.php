<div>
    
    <?php echo e($adiestracions); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/livewire/adiestracion.blade.php ENDPATH**/ ?>