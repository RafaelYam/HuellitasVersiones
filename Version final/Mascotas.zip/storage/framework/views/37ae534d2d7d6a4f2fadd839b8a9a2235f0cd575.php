
<?php $__env->startSection('informacion'); ?>

<div class="fondo container">
    


    <div class="formulario-sintoma ">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sintomas', [])->html();
} elseif ($_instance->childHasBeenRendered('FAGxV4c')) {
    $componentId = $_instance->getRenderedChildComponentId('FAGxV4c');
    $componentTag = $_instance->getRenderedChildComponentTagName('FAGxV4c');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FAGxV4c');
} else {
    $response = \Livewire\Livewire::mount('sintomas', []);
    $html = $response->html();
    $_instance->logRenderedChild('FAGxV4c', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<script>
            function dropdown() {
                return {
                    options: [],
                    selected: [],
                    show: false,
                    open() { this.show = true },
                    close() { this.show = false },
                    isOpen() { return this.show === true },
                    select(index, event) {

                        if (!this.options[index].selected) {

                            this.options[index].selected = true;
                            this.options[index].element = event.target;
                            this.selected.push(index);

                        } else {
                            this.selected.splice(this.selected.lastIndexOf(index), 1);
                            this.options[index].selected = false
                        }
                    },
                    remove(index, option) {
                        this.options[option].selected = false;
                        this.selected.splice(index, 1);


                    },
                    loadOptions() {
                        const options = document.getElementById('select').options;
                        for (let i = 0; i < options.length; i++) {
                            this.options.push({
                                value: options[i].value,
                                text: options[i].innerText,
                                selected: options[i].getAttribute('selected') != null ? options[i].getAttribute('selected') : false
                            });
                        }


                    },
                    selectedValues(){
                        return this.selected.map((option)=>{
                            return this.options[option].value;
                        })
                    }
                }
            }
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/lista/enfermedades.blade.php ENDPATH**/ ?>