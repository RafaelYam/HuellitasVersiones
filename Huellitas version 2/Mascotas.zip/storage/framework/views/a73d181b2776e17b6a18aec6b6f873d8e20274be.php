<nav class="">
  <div class="nav-wrapper ">
    <a href="<?php echo e(route('welcome')); ?>" class="brand-logo">Inicio</a>

    <?php if(Route::has('login')): ?>
    <div align='right' class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
      <?php if(auth()->guard()->check()): ?>
      <ul class="right hide-on-med-and-down">


        <li><a class="dropdown-trigger" href="<?php echo e(route('perfil')); ?>" data-target="dropdown1"><?php echo e(Auth::user()->name); ?> </a></li>
        <li class="col s12 m2"><a href="#">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>

              <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                  this.closest(\'form\').submit();']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                  this.closest(\'form\').submit();']); ?>
                <?php echo e(__('Cerrar Sesion')); ?>

               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </form>
          </a></li>
      </ul>
      <?php else: ?>
      <a href="<?php echo e(route('login')); ?>" class="login">Iniciar Sesión</a>

      <?php if(Route::has('register')): ?>
      <a href="<?php echo e(route('register')); ?>" class="register">Registrar</a>
      <?php endif; ?>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>