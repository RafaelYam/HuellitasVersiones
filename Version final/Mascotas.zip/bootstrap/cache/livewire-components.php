<?php return array (
  'adiestracions' => 'App\\Http\\Livewire\\Adiestracions',
  'crear-animal' => 'App\\Http\\Livewire\\CrearAnimal',
  'cuidadogeneral' => 'App\\Http\\Livewire\\Cuidadogeneral',
  'especies' => 'App\\Http\\Livewire\\Especies',
  'registrar' => 'App\\Http\\Livewire\\Registrar',
  'show-razas' => 'App\\Http\\Livewire\\ShowRazas',
  'sintomas' => 'App\\Http\\Livewire\\Sintomas',
  'vacunas' => 'App\\Http\\Livewire\\Vacunas',
);