<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">




</head>

<body>




    <h2 class="titulo">Huellitas: Veterinario en casa</h2>
    <div class="container" id="container">
        <div class="form-container sign-up-container">
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <h1>Ingresar con tu correo:</h1>

                <span>O usa tu correo electrónico</span>
                <input type="email" placeholder="Correo" name="email" :value="old('email')" required autofocus />
                <input type="password" placeholder="Contraseña" name="password" required autocomplete="current-password" />

                <button>
                    <?php echo e(__('Iniciar sesión')); ?>

                </button>
            </form>
        </div>
        <div class="form-container sign-in-container">

            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <h1>Regístrate:</h1>

                <span>Rellena el formulario con tus datos personales</span>
                <input type="text" placeholder="Nombre" name="name" :value="old('name')" required autofocus />
                <input type="email" placeholder="Email" name="email" :value="old('email')" required />
                <input type="password" placeholder="Contraseña" name="password" required autocomplete="new-password" />
                <input type="password" placeholder="Confirmar contraseña" name="password_confirmation" required />
                <button><?php echo e(__('Registrarse')); ?></button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">

                    <h1>Bienvenido de vuelta!!</h1>
                    <p>Para mantenerte en contacto con nosotros, entra con tu información personal</p>
                    <br>
                    <p>Si no tienes una cuenta, regístrate</p>
                    <button class="ghost" id="signIn">Registrarse</button>
                    <div>
                        <br>
                        <button class="ghost"><a href="">Volver al Inicio</a></button>
                    </div>

                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Hola, amigo!</h1>
                    <p>Ingresa tus datos personales y comienza tu aprendizaje con nosotros</p>
                    <br>
                    <p>Si ya estás registrado, inicia sesión</p>
                    <button class="ghost" id="signUp">Iniciar Seseión</button>
                    <div>
                        <br>
                        <button class="ghost"><a href="">Volver al Inicio</a></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>
            Creado por
            <a target="_blank" href="https://florin-pop.com">Rafael Yam Tamayo</a> y <a target="_blank" href="https://florin-pop.com">Fernanda Tzec Quijano</a>
            Proyecto final para la asignatura Programación Web.
        </p>
    </footer>
    <script>
        const signUpButton = document.getElementById('signUp');
        const signInButton = document.getElementById('signIn');
        const container = document.getElementById('container');

        signUpButton.addEventListener('click', () => {
            container.classList.add("right-panel-active");
        });

        signInButton.addEventListener('click', () => {
            container.classList.remove("right-panel-active");
        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/auth/login.blade.php ENDPATH**/ ?>