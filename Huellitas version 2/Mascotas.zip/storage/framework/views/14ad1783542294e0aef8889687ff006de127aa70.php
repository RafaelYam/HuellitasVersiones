
<?php $__env->startSection('informacion'); ?>


<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>





<form action="<?php echo e(route('mascota.update', $mascota->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <!-- Nombre -->
    <label for="Name">Nombre de la mascota</label>
    <input id="name" name="nombre" type="text" value="<?php echo e($mascota->nombre); ?>" required>

    <!-- Raza -->
    <div class="input-field col s12">
        <select name="raza">
            <option value="" disabled selected>Seleccionar</option>
            <?php $__currentLoopData = $animal2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animald): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option class="Active" value="<?php echo e($animald->id); ?>"><?php echo e($animald->raza); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label>¿Qué mascota tienes?</label>
    </div>

    <!-- Edad -->
    <div class="input-field col s12">
        <select name="edad" value="<?php echo e($mascota->edad); ?>" required>
            <option value="" disabled selected>Seleccionar</option>
            <option value="0 - 3 meses">0 - 3 meses</option>
            <option value="4 - 6 meses">4 - 6 meses</option>
            <option value="7 - 9 meses">7 - 9 meses</option>
            <option value="1 año o más">1 año o más</option>
        </select>
        <label>Edad de la mascota</label>
    </div>

    <!-- Sexo -->
    <div class="input-field col s12">
        <select name="sexo" value="<?php echo e($mascota->sexo); ?>" required>
            <option value="" disabled selected>Seleccionar</option>
            <option value="Macho">Macho</option>
            <option value="Hembra">Hembra</option>
    
        </select>
        <label>Sexo de la mascota</label>
    </div>

    <button class="waves-effect waves-light small btn" type="submit">Enviar Datos</button>
</form>
<script>
    $(document).ready(function() {
        $('select').formSelect();
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/CRUDMascota/edit.blade.php ENDPATH**/ ?>