
<?php $__env->startSection('informacion'); ?>

<div class="row">
    
    <div class="col s5">
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cuidadogeneral', [])->html();
} elseif ($_instance->childHasBeenRendered('M5WYg5d')) {
    $componentId = $_instance->getRenderedChildComponentId('M5WYg5d');
    $componentTag = $_instance->getRenderedChildComponentTagName('M5WYg5d');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('M5WYg5d');
} else {
    $response = \Livewire\Livewire::mount('cuidadogeneral', []);
    $html = $response->html();
    $_instance->logRenderedChild('M5WYg5d', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.miapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mascotas\resources\views/lista/cuidadogeneral.blade.php ENDPATH**/ ?>